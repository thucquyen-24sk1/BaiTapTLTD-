package com.example.baitap2
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val svMe = Sinhvien(
            hoTen = "Nguyen Thi Thuc Quyen",
            maSV = "2415141122115",
            lop = "24SK1",
            Nganh = "Su Pham Cong Nghiep"

        )
        println("THÔNG TIN SINH VIÊN")
        val tvName = findViewById<TextView>(R.id.tvName)
        val tvID = findViewById<TextView>(R.id.tvID)
        val tvClass = findViewById<TextView>(R.id.tvClass)
        val tvMajor = findViewById<TextView>(R.id.tvMajor)

        tvName.text = "Họ và tên: ${svMe.hoTen}"
        tvID.text = "MSSV: ${svMe.maSV}"
        tvClass.text = "Lớp: ${svMe.lop}"
        tvMajor.text = "Ngành: ${svMe.Nganh}"
    }
}
