package com.example.baitap2
import android.widget.TextView

class Sinhvien(val hoTen: String,
               val maSV: String,
               val lop: String,
               val Nganh: String) {
    fun HienThi(
        tvName: TextView,
        tvId: TextView,
        tvClass: TextView,
        tvMajor: TextView
    )
    {
        tvName.text = "Họ và tên: $hoTen"
        tvId.text = "MSSV: $maSV"
        tvClass.text = "Lớp: $lop"
        tvMajor.text = "Ngành: $Nganh"
    }
}